#!/usr/bin/env python

from pycamhd import *

__version__ = '0.6.0'

VERSION = __version__
